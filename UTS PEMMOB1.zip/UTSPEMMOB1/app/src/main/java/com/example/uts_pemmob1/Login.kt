package com.example.uts_pemmob1

// Pastikan kamu mengimpor MainActivity dan Register sesuai dengan package yang digunakan
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.utspemmob1.R

class Login : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge() // Ensure you are using the correct library version for this
        setContentView(R.layout.activity_login)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val btnLogin = findViewById<Button>(R.id.tombol_login)
        val username = findViewById<EditText>(R.id.nama_user1)
        val password = findViewById<EditText>(R.id.pass_user)

        btnLogin.setOnClickListener {
            val userInput = username.text.toString()
            val passInput = password.text.toString()

            // Pastikan UserData.userList ada dan berfungsi dengan baik
            val found = UserData.userList.any { it.username == userInput && it.password == passInput }

            if (found) {
                Toast.makeText(this, "Login berhasil", Toast.LENGTH_SHORT).show()
                startActivity(Intent(this, MainActivity::class.java)) // pastikan MainActivity sudah ada
            } else {
                Toast.makeText(this, "Login gagal. Cek username atau password.", Toast.LENGTH_SHORT).show()
            }
        }

        btnregisterListener()
    }

    private fun btnregisterListener() {
        val regispage1 = findViewById<TextView>(R.id.daftar)
        regispage1.setOnClickListener {
            startActivity(Intent(this, Register::class.java)) // pastikan Register sudah ada
        }
    }

    // Data class User untuk menyimpan data user
    data class User(val username: String, val password: String)
}
