package com.example.uts_pemmob1

data class User(val username: String, val password: String)

object UserData {
    val userList = ArrayList<User>()

}
